# Android / PWA

O frontend já contém manifest e service worker e pode ser instalado como PWA em Android.

Para publicar um APK/AAB comercial, uma etapa de empacotamento ainda é necessária (por exemplo, Capacitor/TWA). O projeto web não deve ser apresentado como APK compilado até existir um artefacto Android assinado.
