# Políticas do Kamba Market — rascunho operacional

## Afiliados
Comissões só se tornam disponíveis após a venda ser confirmada e a encomenda chegar ao estado `completed`. Cancelamentos, devoluções e fraude podem invalidar a comissão.

## Marketplace
É proibido anunciar produtos/serviços ilegais, falsificados, fraudulentos ou que violem direitos de terceiros. O Kamba Market pode suspender anúncios e contas após análise.

## Privacidade
Coletar apenas os dados necessários para autenticação, execução de encomendas, prevenção de fraude, atendimento e obrigações legais. Não solicitar PIN ou credenciais financeiras.
