# Checklist de produção

## Infraestrutura
- Node.js 18+
- PostgreSQL gerido
- Object Storage (S3 compatível) para imagens
- HTTPS/TLS
- Domínio próprio
- DNS e CDN
- Backups automáticos
- Monitorização e alertas

## Segurança
- Segredos somente em variáveis de ambiente
- Rotação de chaves
- Cookies `HttpOnly`, `Secure`, `SameSite`
- CSRF quando aplicável
- Rate limiting distribuído
- WAF/CDN
- Logs sem passwords/tokens
- Processo de resposta a incidentes

## Negócio
- Termos de Uso
- Política de Privacidade
- Política de Afiliados
- Política de reembolsos
- Regras de moderação
- Processo de KYC/verificação quando exigido
- Conta comercial e provedor de pagamentos contratados
