# Kamba Market 4.0 — padrão de produção

Esta versão consolida marketplace, serviços, afiliados, carteira, encomendas, pagamentos, mensagens, PWA e infraestrutura de produção.

## Objetivo comercial
1. Atrair vendedores por publicação gratuita.
2. Monetizar com destaque de anúncios, planos profissionais e comissão por transação.
3. Escalar distribuição com afiliados e links rastreados.
4. Transformar tráfego em receitas através de checkout, recorrência e publicidade futura.

## Segurança operacional
- HTTPS na borda com Caddy.
- PostgreSQL isolado da Internet.
- MinIO/S3 para media, nunca guardar ficheiros binários no PostgreSQL.
- Passwords com scrypt.
- Rate limiting no registo/login.
- Webhooks devem ser idempotentes e assinados.
- Auditoria de operações administrativas e financeiras.
- Backups PostgreSQL e teste periódico de restauração.
- Segredos apenas por ambiente/secret manager.
- Nunca utilizar o provider `mock` com dinheiro real.

## Disponibilidade
Usar pelo menos 2 instâncias da app atrás de um reverse proxy quando o tráfego justificar. PostgreSQL deve ter backup externo e, para alta disponibilidade, réplica gerida pelo provedor.
