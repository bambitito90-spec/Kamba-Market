# Motor de monetização

## Receitas principais
- Comissão de marketplace: configurável por produto/categoria quando migrado para regra persistente.
- Planos de vendedor: Free, Pro, Premium.
- Destaques pagos.
- Comissão afiliada: padrão 5%, configurável.
- Publicidade patrocinada: preparar inventário sem cobrar até existir faturação/entrega real.

## Regra financeira
Uma comissão de afiliado só pode passar de `pending` para `available` quando a encomenda estiver `completed` e não houver disputa, chargeback ou cancelamento.

## Proteções
- Idempotência para pedidos de pagamento.
- Uma única comissão por conversão elegível.
- Não contar auto-compra.
- Não liberar comissão em pagamento pendente.
- Não aceitar manipulação do valor enviado pelo navegador: total deve ser recalculado no servidor.
