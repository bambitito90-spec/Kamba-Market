# Kamba Market 3.2 — roteiro de produção

A versão 3.2 acrescenta a infraestrutura e os scripts para a transição do protótipo JSON para PostgreSQL.

## Sequência recomendada

1. Criar PostgreSQL e definir `DATABASE_URL`.
2. Aplicar `db/schema.sql`.
3. Migrar dados com `node scripts/migrate-json-to-postgres.js`.
4. Transferir as leituras/escritas do servidor para `storage/postgres.js` antes de aceitar tráfego real.
5. Colocar a aplicação atrás de HTTPS/reverse proxy.
6. Configurar backups automáticos e recuperação testada.
7. Ligar o provedor de pagamento comercial e validar webhooks com assinatura + idempotência.
8. Ativar observabilidade, alertas e limites de requisição.

## Estado financeiro

`PAYMENT_PROVIDER=mock` continua sendo somente para testes. Nenhuma comissão ou saldo deve ser liberado com base em uma confirmação do browser do cliente. A fonte de verdade deve ser o evento assinado do provedor.

## Privacidade e segurança

Não guardar dados bancários desnecessários. Mascarar destinos de levantamentos no painel. Não registrar passwords, tokens ou segredos em logs. Rotacionar segredos e usar armazenamento seguro de secrets.
