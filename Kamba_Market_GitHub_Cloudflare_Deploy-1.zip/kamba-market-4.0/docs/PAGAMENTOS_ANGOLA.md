# Pagamentos em Angola — guia de integração

O Kamba Market usa uma camada de adaptadores para não ficar preso a um único provedor.

## Estratégia
1. O checkout cria uma ordem.
2. O adaptador inicia a cobrança.
3. O provedor confirma o pagamento por callback/webhook assinado.
4. Só depois da confirmação a encomenda muda para `paid`.
5. A comissão de afiliado permanece pendente até `completed`.
6. O levantamento do afiliado só usa saldo disponível.

## MULTICAIXA / EMIS
A EMIS informa que gere a Rede MULTICAIXA e disponibiliza infraestrutura de pagamentos online; o MULTICAIXA Express é um canal de pagamentos digitais. Consulte a documentação/credenciamento oficial e use as credenciais emitidas ao comerciante.

## KWiK
O KWiK é uma infraestrutura de transferências instantâneas conta-a-conta; a implementação real depende de participante/provedor e credenciais comerciais. O Kamba Market deve tratar o KWiK como adaptador, não como uma API inventada.

## Regras de segurança
- Nunca guardar PIN, CVV ou palavra-passe bancária.
- Validar assinatura/autenticidade de webhooks.
- Usar idempotency keys para evitar cobranças duplicadas.
- Registar `providerTransactionId`.
- Confirmar valor, moeda e pedido no servidor.
- Separar estados `pending`, `confirmed`, `failed`, `refunded`.
