# Observabilidade

Endpoints previstos:
- `GET /api/health` — processo vivo.
- `GET /api/ready` — pronto para servir.
- `GET /api/admin/stats` — indicadores do negócio.

Em produção, ligar logs estruturados a um agregador e configurar alertas para 5xx, latência, falhas de pagamento e espaço do disco.
